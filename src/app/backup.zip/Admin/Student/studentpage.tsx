export interface StudentPage {
  id: string;
  name: string;
  standard: string; 
  section: string;
  gender: string;
  address: string;
  contactNo: string;
  guardianName: string;
  admissionNo: string;
  dateOfBirth: string;
}
import { useState, useEffect } from 'react';
export default function studentpg() {
  
  const [students, setStudents] = useState([
    { id: 1, name: 'John Doe', section: 'A', standard: 'LKG', gender: 'Male', address: '123 School Lane', contactNo: '555-1234', guardianName: 'Jane Doe', admissionNo: 'ADM001', dateOfBirth: '2019-05-15' },
    { id: 2, name: 'Alice Smith', section: 'B', standard: 'UKG', gender: 'Female', address: '456 Education Ave', contactNo: '555-5678', guardianName: 'Bob Smith', admissionNo: 'ADM002', dateOfBirth: '2018-08-22' },
    { id: 3, name: 'Michael Johnson', section: 'C', standard: '1', gender: 'Male', address: '789 Learning Road', contactNo: '555-9012', guardianName: 'Sarah Johnson', admissionNo: 'ADM003', dateOfBirth: '2017-11-10' },
    { id: 4, name: 'Emily Brown', section: 'A', standard: '2', gender: 'Female', address: '101 Knowledge Street', contactNo: '555-3456', guardianName: 'David Brown', admissionNo: 'ADM004', dateOfBirth: '2016-03-25' },
    { id: 5, name: 'Daniel Wilson', section: 'B', standard: '3', gender: 'Male', address: '202 Wisdom Lane', contactNo: '555-7890', guardianName: 'Lisa Wilson', admissionNo: 'ADM005', dateOfBirth: '2015-07-14' },
    { id: 6, name: 'Olivia Davis', section: 'C', standard: '12', gender: 'Female', address: '303 Smart Road', contactNo: '555-4321', guardianName: 'James Davis', admissionNo: 'ADM006', dateOfBirth: '2006-12-05' },
  ]);

 
  const [sectionFilter, setSectionFilter] = useState('');
  const [standardFilter, setStandardFilter] = useState('');
  const [nameFilter, setNameFilter] = useState('');
  const [filteredStudents, setFilteredStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);

 
  const sections = ['A', 'B', 'C'];
  const standards = ['LKG', 'UKG', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];


  useEffect(() => {
    let result = students;
    
    if (sectionFilter) {
      result = result.filter(student => student.section === sectionFilter);
    }
    
    if (standardFilter) {
      result = result.filter(student => student.standard === standardFilter);
    }
    
    if (nameFilter) {
      result = result.filter(student => 
        student.name.toLowerCase().includes(nameFilter.toLowerCase())
      );
    }
    
    setFilteredStudents(result);
  }, [sectionFilter, standardFilter, nameFilter, students]);

  const handleSubmit = (e) => {
    e.preventDefault();
   
  };


  const handleStudentSelect = (student) => {
    setSelectedStudent(student);
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6 text-center">Student Information System</h1>
      <form onSubmit={handleSubmit} className="bg-white shadow-md rounded p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
          <div>
            <label htmlFor="section" className="block text-sm font-medium text-gray-700 mb-1">
              Section
            </label>
            <select
              id="section"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={sectionFilter}
              onChange={(e) => setSectionFilter(e.target.value)}
            >
              <option value="">All Sections</option>
              {sections.map((section) => (
                <option key={section} value={section}>
                  Section {section}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="standard" className="block text-sm font-medium text-gray-700 mb-1">
              Standard
            </label>
            <select
              id="standard"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={standardFilter}
              onChange={(e) => setStandardFilter(e.target.value)}
            >
              <option value="">All Standards</option>
              {standards.map((standard) => (
                <option key={standard} value={standard}>
                  {standard}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
              Student Name
            </label>
            <input
              type="text"
              id="name"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Search by name"
              value={nameFilter}
              onChange={(e) => setNameFilter(e.target.value)}
            />
          </div>
        </div>
        
        <div className="mt-4 text-center">
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-6 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            Search
          </button>
        </div>
      </form>
      
      <div className="flex flex-col md:flex-row gap-6">
  
        <div className="w-full md:w-1/2">
          <h2 className="text-xl font-semibold mb-3">Students List</h2>
          {filteredStudents.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white shadow-md rounded-lg overflow-hidden">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="py-3 px-4 text-left">Name</th>
                    <th className="py-3 px-4 text-left">Section</th>
                    <th className="py-3 px-4 text-left">Standard</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredStudents.map((student) => (
                    <tr
                      key={student.id}
                      onClick={() => handleStudentSelect(student)}
                      className={`border-b hover:bg-gray-50 cursor-pointer ${
                        selectedStudent?.id === student.id ? 'bg-blue-50' : ''
                      }`}
                    >
                      <td className="py-3 px-4">{student.name}</td>
                      <td className="py-3 px-4">{student.section}</td>
                      <td className="py-3 px-4">{student.standard}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="bg-white shadow-md rounded p-6 text-center text-gray-500">
              No students match the selected filters
            </div>
          )}
        </div>
        
    
        <div className="w-full md:w-1/2">
          <h2 className="text-xl font-semibold mb-3">Student Details</h2>
          {selectedStudent ? (
            <div className="bg-white shadow-md rounded-lg overflow-hidden">
              <div className="bg-blue-500 text-white p-4">
                <h3 className="text-xl font-bold">{selectedStudent.name}</h3>
                <div className="flex space-x-4 mt-1">
                  <span>Section: {selectedStudent.section}</span>
                  <span>Standard: {selectedStudent.standard}</span>
                </div>
              </div>
              <div className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Admission Number</p>
                    <p>{selectedStudent.admissionNo}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Date of Birth</p>
                    <p>{selectedStudent.dateOfBirth}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Gender</p>
                    <p>{selectedStudent.gender}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Guardian Name</p>
                    <p>{selectedStudent.guardianName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Contact Number</p>
                    <p>{selectedStudent.contactNo}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Address</p>
                    <p>{selectedStudent.address}</p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white shadow-md rounded p-6 text-center text-gray-500">
              Select a student to view details
            </div>
          )}
        </div>
      </div>
    </div>
  );
}