"use client";
import { useEffect, useState } from 'react';

export default function ClientOnlyDate() {
  const [date, setDate] = useState('');
  
  useEffect(() => {
    setDate(new Date().toLocaleDateString());
  }, []);
  
  return (
    <div className="text-right">
      <p className="text-sm text-slate-300">Last updated</p>
      <p className="text-lg">{date || '—'}</p>
    </div>
  );
}