import { useState, useEffect } from 'react';

export interface AttendanceRecord {
  student: string;
  status: 'Present' | 'Absent' | 'OD';
  date: string;
}

export interface PercentageRecord {
  [student: string]: string;
}

const students = [
  'Student11', 'Student12', 'Student13', 'Student14', 'Student15',
  'Student16', 'Student17', 'Student18', 'Student19', 'Student20'
];

const StudentAttendance = () => {
  const [attendanceRecords, setAttendanceRecords] = useState<{ [key: string]: string }>({});
  const [submittedRecords, setSubmittedRecords] = useState<AttendanceRecord[]>(() => {
    const savedRecords = localStorage.getItem('submittedAttendanceRecords');
    return savedRecords ? JSON.parse(savedRecords) : [];
  });

  const [dateFilter, setDateFilter] = useState('');
  const [showEditTable, setShowEditTable] = useState(true);
  const [percentageRecords, setPercentageRecords] = useState<PercentageRecord>({});

  useEffect(() => {
    localStorage.setItem('submittedAttendanceRecords', JSON.stringify(submittedRecords));
  }, [submittedRecords]);

  const handleAttendanceChange = (student: string, value: 'Present' | 'Absent' | 'OD') => {
    setAttendanceRecords((prev) => ({
      ...prev,
      [student]: value,
    }));
  };

  const handleSubmit = () => {
    const today = new Date().toISOString().split('T')[0];

    const newRecords = Object.entries(attendanceRecords).map(([student, status]) => ({
      student,
      status: status as 'Present' | 'Absent' | 'OD',
      date: today,
    }));

    setSubmittedRecords([...submittedRecords, ...newRecords]);
    setAttendanceRecords({});
    setShowEditTable(true);
  };

  const handlePercentage = (student: string) => {
    setPercentageRecords((prev) => {
      if (prev[student] !== undefined) {
        const updatedRecords = { ...prev };
        delete updatedRecords[student];
        return updatedRecords;
      }

      const studentRecords = submittedRecords.filter(record => record.student === student);
      const totalDays = studentRecords.length;
      const presentDays = studentRecords.filter(record => record.status === 'Present').length;
      const percentage = totalDays > 0 ? Math.round((presentDays / totalDays) * 100) : 0;

      return { ...prev, [student]: `${percentage}%` };
    });
  };

  const handleEdit = (index: number) => {
    const record = submittedRecords[index];
    setAttendanceRecords({ [record.student]: record.status });
    setSubmittedRecords(submittedRecords.filter((_, i) => i !== index));
    setShowEditTable(false);
  };

  const handleDelete = (index: number) => {
    setSubmittedRecords(submittedRecords.filter((_, i) => i !== index));
  };

  const filteredRecords = submittedRecords.filter(
    (record) => !dateFilter || record.date === dateFilter
  );

  return (
    <div className="w-full">
      <header className="bg-indigo-800 shadow-md p-4 text-white text-lg font-bold">
        STUDENTS ATTENDANCE
      </header>

      <div className="max-w-4xl mx-auto mt-6 px-4">
        <div className="flex justify-between mb-4">
          <div className="flex items-center">
            <label htmlFor="date-filter" className="mr-2 text-sm font-medium">Filter by date:</label>
            <input
              id="date-filter"
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="px-3 py-2 border rounded-md shadow-sm"
            />
          </div>

          <button
            onClick={() => setShowEditTable(!showEditTable)}
            className="px-4 py-2 bg-indigo-600 text-white rounded-md"
          >
            {showEditTable ? "Mark Attendance" : "View Records"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default StudentAttendance;