

// Mock database of students
const students = [
  { id: 1, name: 'John Doe', section: 'A', standard: 'LKG', gender: 'Male', address: '123 School Lane', contactNo: '555-1234', guardianName: 'Jane Doe', admissionNo: 'ADM001', dateOfBirth: '2019-05-15' },
  { id: 2, name: 'Alice Smith', section: 'B', standard: 'UKG', gender: 'Female', address: '456 Education Ave', contactNo: '555-5678', guardianName: 'Bob Smith', admissionNo: 'ADM002', dateOfBirth: '2018-08-22' },
  { id: 3, name: 'Michael Johnson', section: 'C', standard: '1', gender: 'Male', address: '789 Learning Road', contactNo: '555-9012', guardianName: 'Sarah Johnson', admissionNo: 'ADM003', dateOfBirth: '2017-11-10' },
  { id: 4, name: 'Emily Brown', section: 'A', standard: '2', gender: 'Female', address: '101 Knowledge Street', contactNo: '555-3456', guardianName: 'David Brown', admissionNo: 'ADM004', dateOfBirth: '2016-03-25' },
  { id: 5, name: 'Daniel Wilson', section: 'B', standard: '3', gender: 'Male', address: '202 Wisdom Lane', contactNo: '555-7890', guardianName: 'Lisa Wilson', admissionNo: 'ADM005', dateOfBirth: '2015-07-14' },
  { id: 6, name: 'Olivia Davis', section: 'C', standard: '12', gender: 'Female', address: '303 Smart Road', contactNo: '555-4321', guardianName: 'James Davis', admissionNo: 'ADM006', dateOfBirth: '2006-12-05' },
  // Add more student data as needed
];

export default function handler(req, res) {
  if (req.method === 'GET') {
    let filteredStudents = [...students];
    const { section, standard, name } = req.query;
    
    // Apply filters if provided
    if (section) {
      filteredStudents = filteredStudents.filter(
        student => student.section.toLowerCase() === section.toLowerCase()
      );
    }
    
    if (standard) {
      filteredStudents = filteredStudents.filter(
        student => student.standard.toLowerCase() === standard.toLowerCase()
      );
    }
    
    if (name) {
      filteredStudents = filteredStudents.filter(
        student => student.name.toLowerCase().includes(name.toLowerCase())
      );
    }
    
    res.status(200).json(filteredStudents);
  } else {
    // Handle other HTTP methods
    res.setHeader('Allow', ['GET']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}

// pages/api/students/[id].js