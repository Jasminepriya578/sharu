"use client";
import React from "react";
import {
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

export default function Chart() {
  const data = [
    { name: "2022", uv: 300, pv: 2210, amt: 2290 },
    { name: "2023", uv: 200, pv: 2000, amt: 2000 },
    { name: "2024", uv: 278, pv: 2500, amt: 2500 },
    { name: "2025", uv: 189, pv: 2100, amt: 2100 },
  ];

  return (
    <div className="p-6 bg-white dark:bg-gray-900 rounded-lg shadow-lg w w-full max-w-7xl min-w-[300px] mx-auto">

      <h2 className="text-center text-xl md:text-2xl font-bold text-gray-800 dark:text-white animate-fade-in">
        Yearly Data Overview
      </h2>

    
      <div className="mt-8 w-full h-[100px] sm:h-[350px]">
        <ResponsiveContainer className="w-full max-w-7xl min-w-[300px] mx-auto">
          <LineChart
            data={data}
            margin={{ top: 20, right: 30, left: 10, bottom: 10 }}
            className="transition-all duration-500 ease-in-out"
          >

            <CartesianGrid stroke="#e5e7eb" strokeDasharray="4 4" />

            <XAxis
              dataKey="name"
              tick={{ fill: "#6366f1", fontSize: 14 }}
              axisLine={{ stroke: "#6366f1" }}
              tickLine={{ stroke: "#6366f1" }}
              className="text-indigo-500 font-semibold transition-all duration-300 ease-in-out hover:scale-105"
            />

            <YAxis
              tick={{ fill: "#f43f5e", fontSize: 14 }}
              axisLine={{ stroke: "#f43f5e" }}
              tickLine={{ stroke: "#f43f5e" }}
              className="text-red-500 font-bold transition-all duration-300 ease-in-out hover:scale-105"
            />


            <Line
              type="monotone"
              dataKey="uv"
              stroke="#f97316"
              strokeWidth={3}
              dot={{ stroke: "#f97316", strokeWidth: 4, fill: "white" }}
              className="animate-draw-line"
            />

           
            <Tooltip
              contentStyle={{
                backgroundColor: "#f9fafb",
                color: "#1f2937",
                border: "1px solid #e5e7eb",
              }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
