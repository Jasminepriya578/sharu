"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";

interface NavbarProps {
  setSection: React.Dispatch<React.SetStateAction<string>>;
}

const Navbar: React.FC<NavbarProps> = ({ setSection }) => {
  const [activeSection, setActiveSection] = useState("Dashboard");
  const [attendanceExpanded, setAttendanceExpanded] = useState(false);
  const [FeesExpanded, setFeesExpanded] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsMobileMenuOpen(false);
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handleSectionChange = (section: string) => {
    if(section == "Fees"){
      setFeesExpanded(!FeesExpanded);
      return;
    }
    if (section === "Attendance") {
      setAttendanceExpanded(!attendanceExpanded);
      return;
    }

    setActiveSection(section);
    setSection(section);
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      
      <button
        className="lg:hidden fixed top-19 left-1 z-50 bg-slate-800 text-white  px-8 rounded-md"
        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
      >
        ☰
      </button>

      
      <div
        className={`fixed top-0 left-0 h-screen w-64 bg-slate-800 text-white shadow-xl flex flex-col z-40 transition-transform duration-300 
        ${isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0`}
      >
        
        <div className="p-6 border-b border-slate-700 flex justify-between">
          <h2 className="text-2xl font-bold text-center text-white">Admin Panel</h2>
          <button
            className="lg:hidden text-xl text-white"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            ✕
          </button>
        </div>

        
        <nav className="flex flex-col flex-1 py-4">
          <NavItem
            title="Dashboard"
            icon="🏠"
            active={activeSection === "Dashboard"}
            onClick={() => handleSectionChange("Dashboard")}
          />
          <NavItem
            title="Students"
            icon="👨‍🎓"
            active={activeSection === "Students"}
            onClick={() => handleSectionChange("Students")}
          />
          <NavItem
            title="Teachers"
            icon="👨‍🏫"
            active={activeSection === "Teachers"}
            onClick={() => handleSectionChange("Teachers")}
          />
       
          <button
            onClick={() => handleSectionChange("Attendance")}
            className={`flex items-center justify-between px-6 py-3 mb-1 mx-2 rounded-lg transition-all duration-200 ${
              attendanceExpanded || activeSection.includes("Attendance")
                ? "bg-indigo-600 text-white"
                : "text-slate-300 hover:bg-slate-700 hover:text-white"
            }`}
          >
            <div className="flex items-center space-x-3">
              <span className="text-xl">📋</span>
              <span className="font-medium">Attendance</span>
            </div>
            <span
              className={`transition-transform duration-200 ${
                attendanceExpanded ? "rotate-180" : ""
              }`}
            >
              ▼
            </span>
          </button>

          {/* Attendance Submenu */}
          <div
            className={`overflow-hidden transition-all duration-300 pl-4 ${
              attendanceExpanded ? "max-h-40 opacity-100" : "max-h-0 opacity-0"
            }`}
          >
            <NavItem
              title="StudentAttendance"
              active={activeSection === "StudentAttendance"}
              icon="🎓"
              onClick={() => handleSectionChange("StudentAttendance")}
            />
            <NavItem
              title="TeacherAttendance"
              icon="👨‍🏫"
              active={activeSection === "TeacherAttendance"}
              onClick={() => handleSectionChange("TeacherAttendance")}
            />
          </div>
          


          <button
            onClick={() => handleSectionChange("Fees")}
            className={`flex items-center justify-between px-6 py-3 mb-1 mx-2 rounded-lg transition-all duration-200 ${
              FeesExpanded || activeSection.includes("Fees")
                ? "bg-indigo-600 text-white"
                : "text-slate-300 hover:bg-slate-700 hover:text-white"
            }`}
          >
            <div className="flex items-center space-x-3">
              <span className="text-xl">🏦</span>
              <span className="font-medium">Fees</span>
            </div>
            <span
              className={`transition-transform duration-200 ${
                FeesExpanded ? "rotate-180" : ""
              }`}
            >
              ▼
            </span>
          </button>
          <div
            className={`overflow-hidden transition-all duration-300 pl-4 ${
              FeesExpanded? "max-h-40 opacity-100" : "max-h-0 opacity-0"
            }`}
          >
            <NavItem
              title="FeesPayment"
              active={activeSection === "FeesPayment"}
              icon="📜"
              onClick={() => handleSectionChange("FeesPayment")}
            />
            <NavItem
              title="PaymentDetails"
              icon="🧾"
              active={activeSection === "PaymentDetails"}
              onClick={() => handleSectionChange("PaymentDetails")}
            />
      
          </div>
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-slate-700 mt-auto">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center">
              <span className="font-bold">A</span>
            </div>
            <div>
              <p className="text-sm font-medium">Admin User</p>
              <p className="text-xs text-slate-400">admin@example.com</p>
            </div>
          </div>
        </div>
      </div>

      
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black opacity-50 z-30 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        ></div>
      )}
    </>
  );
};

interface NavItemsProps {
  title: string;
  icon: string;
  active: boolean;
  onClick: () => void;
}

const NavItem: React.FC<NavItemsProps> = ({ title, icon, active, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`flex items-center space-x-3 px-6 py-3 mb-1 mx-2 rounded-lg transition-all duration-200 ${
        active ? "bg-indigo-600 text-white" : "text-slate-300 hover:bg-slate-700 hover:text-white"
      }`}
    >
      <span className="text-xl">{icon}</span>
      <span className="font-medium">{title}</span>
      {active && <div className="ml-auto w-2 h-2 rounded-full bg-white"></div>}
    </button>
  );
};

export default Navbar;
