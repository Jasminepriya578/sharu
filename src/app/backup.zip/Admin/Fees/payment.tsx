"use client";
export default function Payment(){
    return (
        <>
       <div className="max-w-lg mx-auto bg-white p-6 rounded-lg shadow-md w-full sm:w-96">
           <h2 className="text-2xl font-semibold text-gray-700 text-center">Payment Form</h2>
           <div className="mt-4">
            <label className="block text-sm font-medium text-gray-600">Full Name</label>
            <input
            type="text"
            className="w-full mt-2 p-2 border rounded-md focus:ring-2 focus:ring-indigo-500"
            placeholder="Enter your name"
            />
              <label className="block text-sm font-medium text-gray-600">Email</label>
            <input
            type="text"
            className="w-full mt-2 p-2 border rounded-md focus:ring-2 focus:ring-indigo-500"
            placeholder="Enter your Email"
            />
            <div className="mt-4 grid grid-cols1 sm:grid-cols2 gap-4 bg-red-300">
                <div>
                    <label className="block text-sm font-medium text-gray-600">Card Holder</label>
                    <input type="text"
                    className="w-full mt-1 p-2 border rounded-md focus:ring-2 focus:ring-indigo-500"
                    placeholder="Enter your Name"
                    ></input>
                </div>
                <div>
      <label className="block text-sm font-medium text-gray-600">Card Number</label>
      <input type="text" className="w-full mt-1 p-2 border rounded-md focus:ring-2 focus:ring-indigo-500" placeholder="1234 5678 9012 3456" />
    </div>
    <div>
      <label className="block text-sm font-medium text-gray-600">Expiry Date</label>
      <input type="text" className="w-full mt-1 p-2 border rounded-md focus:ring-2 focus:ring-indigo-500" placeholder="MM/YY" />
    </div>
    <div className="mt-4">
    <label className="block text-sm font-medium text-gray-600">CVV</label>
    <input type="text" className="w-full mt-1 p-2 border rounded-md focus:ring-2 focus:ring-indigo-500" placeholder="123" />
  </div>
                 
            </div>
            
           </div>
       </div>
        </>
    )
}
