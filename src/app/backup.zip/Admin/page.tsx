"use client";
import React, { useState } from "react";
import Sidebar from '@/app/Admin/Navbar';
import Main from '@/app/Admin/main';

export default function Dashboard() {
  const [section, setSection] = useState<string>(""); 


    return (
        <div className="flex h-screen">
            <Sidebar setSection={setSection} />
            <Main section={section} />
        </div>
    );
}

