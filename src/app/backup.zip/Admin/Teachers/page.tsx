
import { useState, useEffect } from 'react';

export default function teacherspg() {
 
  const teachers = [
    { id: 1, name: 'Jason Robert', subject: 'Mathematics', section: 'A', ClassTeacher: '8', email: 'sharma@example.com',gender:'Male' ,phone: '1234567890' },
    { id: 2, name: 'Vanilla Victoria', subject: 'English', section: 'B', ClassTeacher: '9', email: 'verma@example.com', gender:'Female',phone: '9876543210' },
    { id: 3, name: 'Muthuvel', subject: 'Science', section: 'A',  ClassTeacher: '10', email: 'gupta@example.com', gender:'Male',phone: '1122334455' },
  ];

  const [sectionFilter, setSectionFilter] = useState('');
  const [standardFilter, setStandardFilter] = useState('');
  const [nameFilter, setNameFilter] = useState('');
  const [filteredStudents, setFilteredStudents] = useState(teachers);
  const [selectedStudent, setSelectedStudent] = useState(null);

  
  const sections = ['A', 'B', 'C'];
  const standards = ['LKG', 'UKG', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];
 

  useEffect(() => {
    let result = teachers;
    
    if (sectionFilter) {
      result = result.filter(teacher => teacher.section === sectionFilter);
    }
    
    if (standardFilter) {
      result = result.filter(teacher => teacher.standard === standardFilter);
    }
    
    if (nameFilter) {
      result = result.filter(teacher=> 
        teacher.name.toLowerCase().includes(nameFilter.toLowerCase())
      );
    }
    
    setFilteredStudents(result);
  }, [sectionFilter, standardFilter, nameFilter]);

  
  const handleSubmit = (e) => {
    e.preventDefault();
  };
  const handleStudentSelect = (teacher) => {
    setSelectedStudent(teacher);
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6 text-center">Teacher Information System</h1>
      

      <form onSubmit={handleSubmit} className="bg-white shadow-md rounded p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
  
          <div>
            <label htmlFor="section" className="block text-sm font-medium text-gray-700 mb-1">
              Section
            </label>
            <select
              id="section"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={sectionFilter}
              onChange={(e) => setSectionFilter(e.target.value)}
            >
              <option value="">All Sections</option>
              {sections.map((section) => (
                <option key={section} value={section}>
                  Section {section}
                </option>
              ))}
            </select>
          </div>
          
         
          <div>
            <label htmlFor="standard" className="block text-sm font-medium text-gray-700 mb-1">
              Standard
            </label>
            <select
              id="standard"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={standardFilter}
              onChange={(e) => setStandardFilter(e.target.value)}
            >
              <option value="">All Standards</option>
              {standards.map((standard) => (
                <option key={standard} value={standard}>
                  {standard}
                </option>
              ))}
            </select>
          </div>
        
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
              Student Name
            </label>
            <input
              type="text"
              id="name"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Search by name"
              value={nameFilter}
              onChange={(e) => setNameFilter(e.target.value)}
            />
          </div>
        </div>
        
        <div className="mt-4 text-center">
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-6 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            Search
          </button>
        </div>
      </form>
      <div className="flex flex-col md:flex-row gap-6">
        <div className="w-full md:w-1/2">
          <h2 className="text-xl font-semibold mb-3">Students List</h2>
          {filteredStudents.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white shadow-md rounded-lg overflow-hidden">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="py-3 px-4 text-left">Name</th>
                    <th className="py-3 px-4 text-left">Section</th>
                    <th className="py-3 px-4 text-left">Standard</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredStudents.map((teacher) => (
                    <tr
                      key={teacher.id}
                      onClick={() => handleStudentSelect(teacher)}
                      className={`border-b hover:bg-gray-50 cursor-pointer ${
                        selectedStudent?.id === teacher.id ? 'bg-blue-50' : ''
                      }`}
                    >
                      <td className="py-3 px-4">{teacher.name}</td>
                      <td className="py-3 px-4">{teacher.section}</td>
                      <td className="py-3 px-4">{teacher.ClassTeacher}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="bg-white shadow-md rounded p-6 text-center text-gray-500">
              No students match the selected filters
            </div>
          )}
        </div>

        <div className="w-full md:w-1/2">
          <h2 className="text-xl font-semibold mb-3">Teachers Details</h2>
          {selectedStudent ? (
            <div className="bg-white shadow-md rounded-lg overflow-hidden">
              <div className="bg-blue-500 text-white p-4">
                <h3 className="text-xl font-bold">{selectedStudent.name}</h3>
                <div className="flex space-x-4 mt-1">
                  <span>Class Teacher  {selectedStudent.classTeacher} {selectedStudent.section} </span>
              
                </div>
              </div>
              <div className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Name</p>
                    <p>{selectedStudent.name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Subject</p>
                    <p>{selectedStudent.subject}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Class Teacher</p>
                    <p>{selectedStudent.classTeacher}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Section</p>
                    <p>{selectedStudent.section}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Gender</p>
                    <p>{selectedStudent.gender}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Gmail</p>
                    <p>{selectedStudent.email}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">phone</p>
                    <p>{selectedStudent.phone}</p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white shadow-md rounded p-6 text-center text-gray-500">
              Select a student to view details
            </div>
          )}
        </div>
      </div>
    </div>
  );
}