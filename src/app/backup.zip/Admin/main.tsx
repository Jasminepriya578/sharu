"use client";
import React from "react";
import Students from "@/app/Admin/Student/studentpage";
import Teachers from "@/app/Admin/Teachers/page";
import StudentAttend from "@/app/Admin/Attendance/StudentAttend";
import TeacherAttendance from "@/app/Admin/Attendance/TeacherAttend";
import Payment from "@/app/Admin/Fees/payment";
import DashboardStats from "@/app/Admin/Dashboardstats";

export default function Main({ section }: { section: string }) {
    return (
        <div className="flex-1 p-4 lg:p-6 transition-all duration-300 lg:ml-64">
        
            <header className="w-full bg-gray-800 text-white py-4 px-6 shadow-md fixed top-0 left-0 right-0 lg:left-64 transition-all duration-300">
                <h1 className="text-xl font-semibold">Admin</h1>
            </header>

            <div className="mt-16">
                {!section && <DashboardStats />}
                {section === "Dashboard" && <DashboardStats />}
                {section === "Students" && <Students />}
                {section === "Teachers" && <Teachers />}
                {section === "StudentAttendance" && <StudentAttend />}
                {section === "TeacherAttendance" && <TeacherAttendance />}
              
            {/* {section === "FeesPayment" && <Payment />}*/}
                
            </div>
        </div>
    );
}
