"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation"; 
import Image from "next/image";
import { Eye, EyeOff, User, Lock, ArrowRight, CheckCircle } from 'lucide-react';

const images = ["/about1.jpg", "/ourcamp2.jpg", "/achievement.jpg"];

export default function LoginPage() {
  const router = useRouter();
  const [currentImage, setCurrentImage] = useState(0);
  const [showPassword, setShowPassword] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImage((prevImage) => (prevImage + 1) % images.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
  
    if (!username.trim() || !password.trim()) {
      setError("Please enter both username and password");
      return;
    }
  
    setIsLoading(true);
  
    setTimeout(() => {
      setIsLoading(false);
  
      if (username.startsWith("ers")) {
        router.push("/students"); // Redirect to Student Page
      } else if (username.startsWith("erpa")) {
        router.push("/admin"); // Redirect to Admin Page
      } else {
        setError("Invalid username format! Student usernames should start with 'ers' and Admin usernames should start with 'erpa'.");
      }
    }, 1500);
  };
  return (
    <div className="flex flex-col md:flex-row h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Left Side - Image Slider */}
      <div className="hidden md:block w-3/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-r from-blue-500 to-indigo-600 opacity-90 z-0"></div>
        <div className="absolute -bottom-16 -left-16 w-64 h-64 bg-yellow-400 rounded-full opacity-20"></div>
        <div className="absolute top-16 right-36 w-24 h-24 bg-purple-500 rounded-full opacity-20"></div>

        <div className="h-full flex justify-center items-center p-8 relative z-10">
          <div className="relative w-[600px] h-[550px] bg-white rounded-2xl shadow-2xl overflow-hidden">
            <div className="absolute inset-0 p-3">
              {images.map((img, index) => (
                <div 
                  key={index} 
                  className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                    index === currentImage ? 'opacity-100' : 'opacity-0'
                  }`}
                >
                  <Image
                    src={img}
                    alt={`School Image ${index + 1}`}
                    fill
                    style={{ objectFit: "cover" }}
                    className="rounded-xl"
                    priority={index === 0}
                  />
                </div>
              ))}
            </div>

            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6 text-white">
              <h2 className="text-2xl font-bold mb-2">Welcome Back!</h2>
              <p className="text-sm opacity-90">Log in to access your school portal and resources</p>
            </div>

            <div className="absolute bottom-4 right-4 flex space-x-2">
              {images.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImage(index)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    index === currentImage ? 'bg-white w-4' : 'bg-white/50'
                  }`}
                  aria-label={`View image ${index + 1}`}
                ></button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="w-full md:w-2/5 flex flex-col justify-center md:justify-start md:pt-24 px-6 md:px-12 lg:px-16 relative">
        <div className="absolute top-6 right-6">
          <Image src="/logo.png" alt="School Logo" width={60} height={60} className="drop-shadow-md" />
        </div>

        <div className="mb-10">
          <h1 className="text-3xl font-bold text-gray-900 mb-3">Welcome Back</h1>
          <p className="text-gray-600">
            "Where Learning Begins, and Dreams Take Flight!"
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-100 border border-red-300 text-red-700 rounded-lg text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="w-full max-w-md">
          <div className="mb-6">
            <label className="block text-gray-700 font-medium mb-2" htmlFor="username">
              Username
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                className="w-full pl-10 pr-4 py-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
              />
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-gray-700 font-medium mb-2" htmlFor="password">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input
                id="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className="w-full pl-10 pr-12 py-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
              />
              <button 
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-colors"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className={`w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 px-4 rounded-lg font-medium shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-150 flex items-center justify-center ${isLoading ? 'opacity-80 cursor-not-allowed' : ''}`}
          >
            {isLoading ? "Logging in..." : "Log In"}
            <ArrowRight className="ml-2" size={18} />
          </button>
        </form>
      </div>
    </div>
  );
}
