"use client"; 

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Menu, X, User, Book, Phone, Mail, Home, Calendar, FileText, Upload, CheckCircle } from 'lucide-react';

const AdmissionFormPage = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [photoPreview, setPhotoPreview] = useState(null);

  const totalSteps = 3;

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleNextStep = () => {
    if (step < totalSteps) setStep(step + 1);
  };

  const handlePrevStep = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate submission
    setTimeout(() => {
      setIsSubmitting(false);
      alert("Application submitted successfully!");
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex flex-col items-center">
      {/* Navigation Bar */}
      <nav className="bg-white shadow-lg fixed w-full top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center py-4">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <Image src="/logo.png" alt="School Logo" width={50} height={30} />
            <span className="text-xl font-bold text-blue-900 hidden sm:block"> School</span>
          </Link>
    
          {/* Desktop Menu */}
          <div className="hidden md:flex items-center w-full justify-end space-x-8 text-lg font-semibold">
  {/* Navigation Links */}
  <div className="flex space-x-8">
    <Link href="/" className="text-gray-800 hover:text-blue-600 transition duration-300 flex items-center gap-1">
      Home
    </Link>
    <Link href="/about" className="text-gray-800 hover:text-blue-600 transition duration-300 flex items-center gap-1">
      About Us
    </Link>
    <Link href="/contact" className="text-gray-800 hover:text-blue-600 transition duration-300 flex items-center gap-1">
      Contact Us
    </Link>
  </div>

  {/* Login Button (Desktop) */}
  <Link 
    href="/login" 
    className="flex items-center gap-2 bg-yellow-400 text-blue-900 px-6 py-2 rounded-full font-bold hover:bg-yellow-500 transition shadow-md"
  >
    <User size={18} /> Login
  </Link>
</div>

          {/* Mobile Menu Toggle Button */}
          <button 
            className="md:hidden text-blue-900 hover:bg-blue-50 p-2 rounded-full transition"
            onClick={() => setIsOpen(!isOpen)}
            aria-label="Toggle mobile menu"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
    
        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden bg-white border-t py-4 space-y-4 text-center animate-fadeIn">
            <Link href="/" className="block text-lg text-black hover:text-blue-500 hover:bg-blue-50 py-2">
              <div className="flex items-center justify-center gap-2">
                <Home size={18} /> Home
              </div>
            </Link>
            <Link href="/about" className="block text-lg text-black hover:text-blue-500 hover:bg-blue-50 py-2">
              <div className="flex items-center justify-center gap-2">
                <Book size={18} /> About Us
              </div>
            </Link>
            <Link href="/contact" className="block text-lg text-black hover:text-blue-500 hover:bg-blue-50 py-2">
              <div className="flex items-center justify-center gap-2">
                <Phone size={18} /> Contact Us
              </div>
            </Link>
            <div className="px-4 pt-2">
              <Link href="/login" className="flex items-center justify-center gap-2 bg-yellow-400 text-blue-900 px-6 py-2 rounded-full font-bold hover:bg-yellow-500 shadow-md">
                <User size={18} /> Login
              </Link>
            </div>
          </div>
        )}
      </nav>

      {/* Main Content with padding top to account for fixed navbar */}
      <div className="w-full max-w-4xl mx-auto pt-24 px-4 pb-16">
        {/* Form Header with Progress Indicator */}
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-blue-900 mb-4">
            Application Form for Admission
          </h1>
          
          {/* Progress Bar */}
          <div className="w-full max-w-md mx-auto">
            <div className="flex justify-between mb-2">
              {Array.from({ length: totalSteps }).map((_, i) => (
                <div 
                  key={i} 
                  className={`flex flex-col items-center ${i+1 <= step ? 'text-blue-700' : 'text-gray-400'}`}
                >
                  <div 
                    className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${
                      i+1 < step ? 'bg-green-500 text-white' : i+1 === step ? 'bg-blue-600 text-white' : 'bg-gray-200'
                    }`}
                  >
                    {i+1 < step ? <CheckCircle size={16} /> : i+1}
                  </div>
                  <span className="text-xs font-medium hidden sm:block">
                    {i === 0 ? 'Admission' : i === 1 ? 'Student Details' : 'Parent Details'}
                  </span>
                </div>
              ))}
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-blue-600 h-2.5 rounded-full transition-all duration-500"
                style={{ width: `${((step - 1) / (totalSteps - 1)) * 100}%` }}
              ></div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Step 1: Admission Section */}
          {step === 1 && (
            <div className="bg-white rounded-lg shadow-lg p-6 border-l-4 border-blue-600 animate-fadeIn">
              <h2 className="text-xl font-bold text-blue-900 mb-6 flex items-center">
                <FileText className="mr-2" size={24} /> Admission Information
              </h2>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-1">
                  <label className="text-sm font-medium text-gray-700">Select Branch *</label>
                  <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                    <option value="">-- Select Branch --</option>
                    <option value="KPHP">sub campus</option>
                    <option value="Main Campus">Main Campus</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-sm font-medium text-gray-700">Registration Number *</label>
                  <input
                    type="text"
                    placeholder="Enter registration number"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                    required
                  />
                </div>
              </div>

              <div className="mt-6 space-y-1">
                <label className="text-sm font-medium text-gray-700">Upload Student Photo *</label>
                <div className="flex items-center space-x-4">
                  <div className="flex-1">
                    <label className="flex flex-col items-center px-4 py-6 bg-white text-blue rounded-lg shadow-lg tracking-wide border border-blue border-dashed cursor-pointer hover:bg-blue-50 transition">
                      <Upload className="w-8 h-8 text-blue-500" />
                      <span className="mt-2 text-base leading-normal">Select a photo</span>
                      <input 
                        type="file" 
                        className="hidden" 
                        accept="image/*"
                        onChange={handlePhotoChange}
                        required
                      />
                    </label>
                  </div>
                  
                  {photoPreview && (
                    <div className="w-24 h-24 relative">
                      <div className="absolute inset-0 rounded-lg overflow-hidden border-2 border-blue-500">
                        <div 
                          className="w-full h-full bg-cover bg-center"
                          style={{ backgroundImage: `url(${photoPreview})` }}
                        />
                      </div>
                    </div>
                  )}
                </div>
                <p className="text-xs text-gray-500 mt-1">Upload a clear passport size photo (JPEG/PNG, max 2MB)</p>
              </div>
            </div>
          )}

          {/* Step 2: Student Details */}
          {step === 2 && (
            <div className="bg-white rounded-lg shadow-lg p-6 border-l-4 border-blue-600 animate-fadeIn">
              <h2 className="text-xl font-bold text-blue-900 mb-6 flex items-center">
                <User className="mr-2" size={24} /> Student Details
              </h2>

              <div className="grid md:grid-cols-3 gap-6">
                <div className="space-y-1">
                  <label className="text-sm font-medium text-gray-700">First Name *</label>
                  <input
                    type="text"
                    placeholder="Enter first name"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                    required
                  />
                </div>
                
                <div className="space-y-1">
                  <label className="text-sm font-medium text-gray-700">Middle Name</label>
                  <input
                    type="text"
                    placeholder="Enter middle name"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                  />
                </div>
                
                <div className="space-y-1">
                  <label className="text-sm font-medium text-gray-700">Last Name *</label>
                  <input
                    type="text"
                    placeholder="Enter last name"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-6 mt-6">
                <div className="space-y-1">
                  <label className="text-sm font-medium text-gray-700">Gender *</label>
                  <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                    <option value="">-- Select Gender --</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                
                <div className="space-y-1">
                  <label className="text-sm font-medium text-gray-700">Date of Birth *</label>
                  <div className="relative">
                    <Calendar className="absolute top-3 left-3 text-gray-500" size={20} />
                    <input
                      type="date"
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-1">
                  <label className="text-sm font-medium text-gray-700">Class Applying For *</label>
                  <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                    <option value="">-- Select Class --</option>
                    <option value="4th">4th Standard</option>
                    <option value="5th">5th Standard</option>
                    <option value="6th">6th Standard</option>
                    <option value="7th">7th Standard</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Parent/Guardian Details */}
          {step === 3 && (
            <div className="bg-white rounded-lg shadow-lg p-6 border-l-4 border-blue-600 animate-fadeIn">
              <h2 className="text-xl font-bold text-blue-900 mb-6 flex items-center">
                <User className="mr-2" size={24} /> Parent/Guardian Details
              </h2>

              {/* Primary Contact */}
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div className="space-y-1">
                  <label className="text-sm font-medium text-gray-700">Primary Contact Person *</label>
                  <input
                    type="text"
                    placeholder="Name of the Parent/Guardian"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                    required
                  />
                </div>
                
                <div className="space-y-1">
                  <label className="text-sm font-medium text-gray-700">Relation *</label>
                  <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                    <option value="">-- Choose Relation --</option>
                    <option value="Father">Father</option>
                    <option value="Mother">Mother</option>
                    <option value="Guardian">Guardian</option>
                  </select>
                </div>
              </div>

              {/* Father's Details */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-blue-700 mb-4 flex items-center">
                  <User className="mr-2" size={18} /> Father's Details
                </h3>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700">First Name *</label>
                    <input
                      type="text"
                      placeholder="First name"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                      required
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700">Last Name *</label>
                    <input
                      type="text"
                      placeholder="Last name"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                      required
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700">Education Qualification</label>
                    <input
                      type="text"
                      placeholder="Highest education"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700">Occupation</label>
                    <input
                      type="text"
                      placeholder="Current occupation"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700">Phone Number *</label>
                    <div className="relative">
                      <Phone className="absolute top-3 left-3 text-gray-500" size={20} />
                      <input
                        type="tel"
                        placeholder="Phone number"
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute top-3 left-3 text-gray-500" size={20} />
                      <input
                        type="email"
                        placeholder="Email address"
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="mt-4 space-y-1">
                  <label className="text-sm font-medium text-gray-700">Residential Address</label>
                  <div className="relative">
                    <Home className="absolute top-3 left-3 text-gray-500" size={20} />
                    <textarea 
                      placeholder="Enter complete address"
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition min-h-[100px]"
                    ></textarea>
                  </div>
                </div>
              </div>

              {/* Mother's Details */}
              <div>
                <h3 className="text-lg font-semibold text-blue-700 mb-4 flex items-center">
                  <User className="mr-2" size={18} /> Mother's Details
                </h3>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700">First Name *</label>
                    <input
                      type="text"
                      placeholder="First name"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                      required
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700">Last Name *</label>
                    <input
                      type="text"
                      placeholder="Last name"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                      required
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700">Education Qualification</label>
                    <input
                      type="text"
                      placeholder="Highest education"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700">Occupation</label>
                    <input
                      type="text"
                      placeholder="Current occupation"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700">Phone Number *</label>
                    <div className="relative">
                      <Phone className="absolute top-3 left-3 text-gray-500" size={20} />
                      <input
                        type="tel"
                        placeholder="Phone number"
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute top-3 left-3 text-gray-500" size={20} />
                      <input
                        type="email"
                        placeholder="Email address"
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="mt-4 space-y-1">
                  <label className="text-sm font-medium text-gray-700">Residential Address</label>
                  <div className="relative">
                    <Home className="absolute top-3 left-3 text-gray-500" size={20} />
                    <textarea 
                      placeholder="Enter complete address"
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition min-h-[100px]"
                    ></textarea>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-6">
            {step > 1 ? (
              <button
                type="button"
                onClick={handlePrevStep}
                className="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg font-medium hover:bg-gray-300 transition flex items-center"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Previous
              </button>
            ) : (
              <div></div>
            )}
            
            {step < totalSteps ? (
              <button
                type="button"
                onClick={handleNextStep}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition flex items-center"
              >
                Next
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            ) : (
              <button
                type="submit"
                className={`px-6 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition flex items-center ${isSubmitting ? 'opacity-70 cursor-not-allowed' : ''}`}
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </>
                ) : (
                  <>
                    Submit Application
                    <CheckCircle className="ml-2" size={20} />
                  </>
                )}
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

export default AdmissionFormPage;