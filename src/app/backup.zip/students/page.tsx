"use client"
import React from 'react'
import StudentAttendanceComponent from './components/StudentAttendanceComponent'
import Navbar from '../master/components/Navbar'
const page = () => {
  return (
    <div>
        <Navbar/>
        <StudentAttendanceComponent />
    </div>
  )
}

export default page