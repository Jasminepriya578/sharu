import { NextResponse } from "next/server";

// Simulated attendance data (will reset on each request)
let attendanceData = [
  { id: 1, staffId: "EMP001", timestamp: new Date().toISOString(), status: "Present" },
  { id: 2, staffId: "EMP002", timestamp: new Date().toISOString(), status: "Absent" },
  { id: 3, staffId: "EMP003", timestamp: new Date().toISOString(), status: "Late" },
];

// Handle GET request
export async function GET() {
  return NextResponse.json(attendanceData, { status: 200 });
}

// Handle PUT request for updating attendance
export async function PUT(req: Request) {
  try {
    const updatedEntry = await req.json();
    const index = attendanceData.findIndex((entry) => entry.id === updatedEntry.id);

    if (index === -1) {
      return NextResponse.json({ message: "Record not found" }, { status: 404 });
    }

    attendanceData[index] = updatedEntry;
    return NextResponse.json({ message: "Updated successfully" }, { status: 200 });
  } catch (error) {
    return NextResponse.json({ message: "Error updating record" }, { status: 500 });
  }
}

// Handle DELETE request
export async function DELETE(req: Request) {
  try {
    const { id } = await req.json();
    attendanceData = attendanceData.filter((entry) => entry.id !== id);
    return NextResponse.json({ message: "Deleted successfully" }, { status: 200 });
  } catch (error) {
    return NextResponse.json({ message: "Error deleting record" }, { status: 500 });
  }
}
