"use client";
import React, { useState } from "react";
import Sidebar from "@/app/Admin2/Navbar2";
export default function Layout({children}:{children:React.ReactNode}){
    const [currentSection, setCurrentSection] = useState("Dashboard");
    return(
        
            <div className="flex h-screen">
             <Sidebar setSection={setCurrentSection} />
             <div className="flex-1  overflow-auto">{children}</div>
            </div>
        
    )
}