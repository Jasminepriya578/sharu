"use client";
import React from "react";
import Students from "@/app/Admin/Student/studentpage";
import Teachers from "@/app/Admin/Teachers/page";
import DashboardStats from "@/app/Admin2/Dashboard2"; 

export default function Main({ section }: { section: string }) {
    return (
        <div className="flex-1 p-6 ml-64">
            <header className="w-full bg-gray-800 text-white py-4 px-6 shadow-md fixed top-0 left-0 right-0">
                <h1 className="text-xl font-semibold">Admin</h1>
            </header>

            <div className="mt-16">
                {!section && <DashboardStats />} 
                {section === "Dashboard" && <DashboardStats />}
                  {section === "Students" && <Students />}
                {section === "Teachers" && <Teachers />}
                 
            </div>
        </div>
    );
}
