"use client";
import React,{useState} from "react";
import Link from "next/link";
interface NavbarProps {
  setSection: React.Dispatch<React.SetStateAction<string>>;
}
const Navbar: React.FC<NavbarProps> = ({ setSection }) => {
  const [activeSection, setActiveSection] = useState("Dashboard");

  const handleSectionChange = (section: string) => {
    setActiveSection(section);
    setSection(section);
  };

    return(
      <div className="w-64 bg-slate-800 h-screen fixed top-0 left-0 shadow-xl text-white flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-slate-700">
        <h2 className="text-2xl font-bold text-center text-white">Admin Panel</h2>
      </div>
      <nav className="flex flex-col flex-1 py-4">
      <NavItem 
          title="Dashboard" 
          icon="🏠" 
          active={activeSection === "Dashboard"} 
          onClick={() => handleSectionChange("Dashboard")} 
        />
        <NavItem 
          title="Students" 
          icon="👨‍🎓" 
          active={activeSection === "Students"} 
          onClick={() => handleSectionChange("Students")} 
        />
        <NavItem 
          title="Teachers" 
          icon="👨‍🏫" 
          active={activeSection === "Teachers"} 
          onClick={() => handleSectionChange("Teachers")} 
        />
       
      </nav>


      <div className="p-4 border-t border-slate-700 mt-auto">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center">
            <span className="font-bold">A</span>
          </div>
          <div>
            <p className="text-sm font-medium">Admin User</p>
            <p className="text-xs text-slate-400">admin@example.com</p>
          </div>
        </div>
      </div>
    </div>

 
    );
}


interface NavItemsProps{
  title:String;
  icon:string;
  active:boolean;
  onClick:() => void
 }

 const NavItem: React.FC<NavItemsProps>=({title,icon, active, onClick })=>{
  return (
    <button
    onClick={onClick}
    className={`flex items-center space-x-3 px-6 py-3 mb-1 mx-2 rounded-lg transition-all duration-200 ${
      active 
        ? "bg-indigo-600 text-white" 
        : "text-slate-300 hover:bg-slate-700 hover:text-white"
    }`}
  >
  <span className="text-xl">{icon}</span>
  <span className="font-medium">{title}</span>
  {active && (
    <div className="ml-auto w-2 h-2 rounded-full bg-white"></div>
  )}
    
    
            </button>
  )
  
 }
  
export default Navbar;
