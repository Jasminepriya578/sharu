"use client";
import React, { useState } from "react";
import Sidebar from '@/app/Admin2/Navbar2';
import Main from '@/app/Admin2/main2';

export default function Dashboard() {
  const [section, setSection] = useState<string>(""); 


    return (
        <div className="flex h-screen">
            <Sidebar setSection={setSection} />
            <Main section={section} />
        </div>
    );
}

