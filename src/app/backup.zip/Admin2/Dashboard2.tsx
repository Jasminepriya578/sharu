"use client";
import Chart from '@/app/Admin2/charts2';
import React, { useEffect, useState } from "react";
import ClientDate from '@/app/Admin/ClientDate';
import DonationsOverview from '@/app/Admin2/DonationOverview';
import { motion } from "framer-motion";

import DonationsSummaryCard from './DonationSummary';
export default function Main() {

    const [students, setStudents] = useState(0);
    const [teachers, setTeachers] = useState(0);

    useEffect(() => {
        const targetStudents = 500;
        const targetTeachers = 40;
        let startTime = null;
        const duration = 2000; 
        
        const animateCount = (timestamp) => {
          if (!startTime) startTime = timestamp;
          const progress = Math.min((timestamp - startTime) / duration, 1);
          
          setStudents(Math.floor(progress * targetStudents));
          setTeachers(Math.floor(progress * targetTeachers));
          
          if (progress < 1) {
            requestAnimationFrame(animateCount);
          }
        };
        
        requestAnimationFrame(animateCount);
      }, []);

    return (
        <>
       <div className="bg-slate-800 text-white p-6 rounded-lg shadow-md mb-6">
  <div className="flex justify-between items-center">
    <div>
      <h3 className="text-xl font-semibold mb-2">Dashboard Overview</h3>
      <p className="text-slate-300">Welcome to your admin dashboard</p>
    </div>
  
    <ClientDate/>
  </div>
</div>



<div className="grid grid-cols-1 md:grid-cols-2 gap-6">
    
    <DonationsSummaryCard />
    <div className="p-6 bg-yellow-500 text-white rounded-lg shadow-lg hover:shadow-xl hover:bg-yellow-600 transform hover:-translate-y-1 transition-all duration-300 ease-in-out cursor-pointer">
      <div className="flex justify-between items-center mb-4">
        <p className="text-lg font-medium">Pending Payments</p>
        <div className="w-10 h-10 rounded-full bg-yellow-400 flex items-center justify-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
      </div>
      <motion.span
        className="text-4xl font-bold block"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        $24,350
      </motion.span>
      <p className="text-sm mt-2 text-yellow-100">Due by March 15, 2025</p>
    </div>
    <DonationsOverview />
    </div>
            <div className="flex-1 p-6 mt-16 ml  max-w-7xl mx-auto">
                <h2 className="text-2xl font-semibold mb-6">Total</h2>

         
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
             
                <div className="p-6 bg-blue-500 text-white rounded-lg shadow-lg">
  <div className="flex justify-between items-center mb-4">
    <p className="text-lg font-medium">Total Students</p>
    <div className="w-10 h-10 rounded-full bg-blue-400 flex items-center justify-center">
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
      </svg>
    </div>
  </div>
  <motion.span
    className="text-4xl font-bold block"
    initial={{ opacity: 0, scale: 0.8 }}
    animate={{ opacity: 1, scale: 1 }}
    transition={{ duration: 0.8, ease: "easeOut" }}
  >
    {students}
  </motion.span>
  <p className="text-sm mt-2 text-blue-100">Currently enrolled</p>
</div>

<div className="p-6 bg-green-500  text-white rounded-lg shadow-lg ">
<div className="flex justify-between items-center mb-4">
<p className="text-lg font-medium">Teachers</p>
    <div className="w-10 h-10 rounded-full bg-blue-400 flex items-center justify-center">
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
      </svg>
          </div>
          </div>        
          
  <motion.span
    className="text-4xl font-bold block"
    initial={{ opacity: 0, scale: 0.8 }}
    animate={{ opacity: 1, scale: 1 }}
    transition={{ duration: 0.8, ease: "easeOut" }}
  >
    {teachers}
  </motion.span>
  <p className="text-sm mt-2 text-blue-100">Working Professionals</p>
</div>
                   <div className='col-span-1 md:col-span-2 bg-white p-6 mt-6'>
                    <h3 className="text-xl font-semibold mb-4">Performance Overview</h3>
                    <Chart />
                    </div>
                    
              </div>
            </div>
            
        </>
    );
}
