"use client";
import React from 'react';

export default function DonationsOverview() {
  const totalDonations = "$125,750";
  const pendingPayments = "$24,350";
  const paidStudents = 320;
  const unpaidStudents = 180;
  const nextDueDate = "March 15, 2025";
  
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 col-span-1 md:col-span-2">
      <h3 className="text-xl font-semibold mb-4">Donations & Payments</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-indigo-50 rounded-lg p-4 border-l-4 border-indigo-500">
          <p className="text-sm text-gray-600">Total Donations</p>
          <p className="text-2xl font-bold text-indigo-700">{totalDonations}</p>
        </div>
        
        <div className="bg-amber-50 rounded-lg p-4 border-l-4 border-amber-500">
          <p className="text-sm text-gray-600">Pending Payments</p>
          <p className="text-2xl font-bold text-amber-700">{pendingPayments}</p>
          <p className="text-xs text-gray-500 mt-1">Next due: {nextDueDate}</p>
        </div>
        
        <div className="bg-emerald-50 rounded-lg p-4 border-l-4 border-emerald-500">
          <p className="text-sm text-gray-600">Payment Status</p>
          <div className="flex justify-between items-center mt-2">
            <div>
              <p className="text-sm font-medium">Paid</p>
              <p className="text-xl font-bold text-emerald-700">{paidStudents}</p>
            </div>
            <div className="h-10 w-px bg-gray-300 mx-2"></div>
            <div>
              <p className="text-sm font-medium">Unpaid</p>
              <p className="text-xl font-bold text-red-600">{unpaidStudents}</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-gray-50 rounded-lg p-4">
        <h4 className="font-medium mb-2">Recent Transactions</h4>
        <div className="space-y-2">
          <div className="flex justify-between items-center p-2 bg-white rounded border border-gray-200">
            <div>
              <p className="font-medium">John Doe</p>
              <p className="text-xs text-gray-500">ID: ST12345</p>
            </div>
            <div className="text-right">
              <p className="font-medium text-green-600">$250.00</p>
              <p className="text-xs text-gray-500">March 5, 2025</p>
            </div>
          </div>
          <div className="flex justify-between items-center p-2 bg-white rounded border border-gray-200">
            <div>
              <p className="font-medium">Sarah Smith</p>
              <p className="text-xs text-gray-500">ID: ST12346</p>
            </div>
            <div className="text-right">
              <p className="font-medium text-green-600">$250.00</p>
              <p className="text-xs text-gray-500">March 3, 2025</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}