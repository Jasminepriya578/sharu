"use client"
import React from 'react'
import TeacherAttendanceComponent from './components/TeacherAttendanceComponent'
import Navbar from '../master/components/Navbar'
import AssignmentPostingPortal from './components/AssignmentPostingPortal'
const page = () => {
  return (
    <div>
        <Navbar/>
        <AssignmentPostingPortal/>
    </div>
  )
}

export default page