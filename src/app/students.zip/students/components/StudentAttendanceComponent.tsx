import React, { useState } from 'react';

interface AttendanceSummary {
  presentDays: number;
  absentDays: number;
  lateDays: number;
  halfDays: number;
  totalWorkingDays: number;
  percentage: number;
}

interface StudentData {
  name: string;
  class: string;
  rollNo: string;
  admissionNo: string;
  photo: string;
  currentMonthAttendance: AttendanceSummary;
  yearlyAttendance: AttendanceSummary;
}

interface MonthlyAttendance {
  month: string;
  working: number;
  present: number;
  percentage: number;
}

type DailyAttendanceStatus = 'present' | 'absent' | 'late' | 'half-day' | 'holiday' | string;

interface DailyAttendanceRecord {
  date: string;
  day: string;
  status: DailyAttendanceStatus;
}

const StudentAttendanceComponent: React.FC = () => {
  // Sample student data
  const [studentData, setStudentData] = useState<StudentData>({
    name: "Rahul Kumar",
    class: "Class 8B",
    rollNo: "14",
    admissionNo: "ADM2023084",
    photo: "/api/placeholder/100/100",
    currentMonthAttendance: {
      presentDays: 18,
      absentDays: 2,
      lateDays: 1,
      halfDays: 1,
      totalWorkingDays: 22,
      percentage: 81.8
    },
    yearlyAttendance: {
      presentDays: 176,
      absentDays: 15,
      lateDays: 8,
      halfDays: 5,
      totalWorkingDays: 204,
      percentage: 86.3
    }
  });

  // Monthly attendance data
  const [monthlyData, setMonthlyData] = useState<MonthlyAttendance[]>([
    { month: "April", working: 22, present: 20, percentage: 90.9 },
    { month: "May", working: 18, present: 16, percentage: 88.9 },
    { month: "June", working: 16, present: 13, percentage: 81.3 },
    { month: "July", working: 22, present: 20, percentage: 90.9 },
    { month: "August", working: 21, present: 17, percentage: 81.0 },
    { month: "September", working: 20, present: 18, percentage: 90.0 },
    { month: "October", working: 18, present: 15, percentage: 83.3 },
    { month: "November", working: 20, present: 17, percentage: 85.0 },
    { month: "December", working: 16, present: 14, percentage: 87.5 },
    { month: "January", working: 20, present: 19, percentage: 95.0 },
    { month: "February", working: 22, present: 18, percentage: 81.8 },
  ]);

  // Daily attendance history for the selected month
  const [selectedMonth, setSelectedMonth] = useState<string>("February");
  const [dailyAttendance, setDailyAttendance] = useState<DailyAttendanceRecord[]>([
    { date: "2025-02-01", day: "Sat", status: "present" },
    { date: "2025-02-02", day: "Sun", status: "holiday" },
    { date: "2025-02-03", day: "Mon", status: "present" },
    { date: "2025-02-04", day: "Tue", status: "present" },
    { date: "2025-02-05", day: "Wed", status: "present" },
    { date: "2025-02-06", day: "Thu", status: "absent" },
    { date: "2025-02-07", day: "Fri", status: "present" },
    { date: "2025-02-08", day: "Sat", status: "present" },
    { date: "2025-02-09", day: "Sun", status: "holiday" },
    { date: "2025-02-10", day: "Mon", status: "present" },
    { date: "2025-02-11", day: "Tue", status: "present" },
    { date: "2025-02-12", day: "Wed", status: "present" },
    { date: "2025-02-13", day: "Thu", status: "half-day" },
    { date: "2025-02-14", day: "Fri", status: "present" },
    { date: "2025-02-15", day: "Sat", status: "present" },
    { date: "2025-02-16", day: "Sun", status: "holiday" },
    { date: "2025-02-17", day: "Mon", status: "present" },
    { date: "2025-02-18", day: "Tue", status: "present" },
    { date: "2025-02-19", day: "Wed", status: "absent" },
    { date: "2025-02-20", day: "Thu", status: "present" },
    { date: "2025-02-21", day: "Fri", status: "late" },
    { date: "2025-02-22", day: "Sat", status: "present" },
    { date: "2025-02-23", day: "Sun", status: "holiday" },
    { date: "2025-02-24", day: "Mon", status: "present" },
    { date: "2025-02-25", day: "Tue", status: "present" },
    { date: "2025-02-26", day: "Wed", status: "present" },
    { date: "2025-02-27", day: "Thu", status: "present" },
    { date: "2025-02-28", day: "Fri", status: "present" },
  ]);

  // Handler for month selection
  const handleMonthSelect = (month: string): void => {
    setSelectedMonth(month);
    // In a real app, you might fetch daily attendance data for the selected month here
  };

  // Function to get status color based on percentage
  const getStatusColor = (percentage: number): { bg: string; text: string } => {
    if (percentage >= 90) return { bg: 'bg-green-500', text: 'text-green-700' };
    if (percentage >= 75) return { bg: 'bg-yellow-500', text: 'text-yellow-700' };
    return { bg: 'bg-red-500', text: 'text-red-700' };
  };

  // Function to get status color for daily attendance
  const getDayStatusColor = (status: DailyAttendanceStatus): string => {
    switch (status) {
      case 'present': return 'bg-green-500';
      case 'absent': return 'bg-red-500';
      case 'late': return 'bg-yellow-500';
      case 'half-day': return 'bg-blue-500';
      case 'holiday': return 'bg-gray-300';
      default: return 'bg-gray-200';
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      {/* Student Profile Header */}
      <div className="flex items-center mb-6 p-4 bg-indigo-50 rounded-lg">
        <div className="mr-4">
          <img 
            src={studentData.photo} 
            alt={studentData.name} 
            className="h-16 w-16 rounded-full object-cover border-2 border-indigo-300"
          />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-800">{studentData.name}</h1>
          <div className="text-sm text-gray-600">
            <span className="mr-4">Class: {studentData.class}</span>
            <span className="mr-4">Roll No: {studentData.rollNo}</span>
            <span>Admission No: {studentData.admissionNo}</span>
          </div>
        </div>
      </div>
      
      {/* Attendance Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {/* Current Month Card */}
        <div className="bg-white border rounded-lg shadow-sm p-4">
          <h2 className="text-lg font-semibold mb-3">Current Month Attendance</h2>
          <div className="flex items-center mb-3">
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div 
                className={`h-4 rounded-full ${getStatusColor(studentData.currentMonthAttendance.percentage).bg}`} 
                style={{ width: `${studentData.currentMonthAttendance.percentage}%` }}
              ></div>
            </div>
            <span className={`ml-3 font-bold ${getStatusColor(studentData.currentMonthAttendance.percentage).text}`}>
              {studentData.currentMonthAttendance.percentage}%
            </span>
          </div>
          <div className="grid grid-cols-4 gap-2 text-center">
            <div className="bg-green-100 p-2 rounded">
              <div className="text-green-800 font-bold">{studentData.currentMonthAttendance.presentDays}</div>
              <div className="text-xs text-green-600">Present</div>
            </div>
            <div className="bg-red-100 p-2 rounded">
              <div className="text-red-800 font-bold">{studentData.currentMonthAttendance.absentDays}</div>
              <div className="text-xs text-red-600">Absent</div>
            </div>
            <div className="bg-yellow-100 p-2 rounded">
              <div className="text-yellow-800 font-bold">{studentData.currentMonthAttendance.lateDays}</div>
              <div className="text-xs text-yellow-600">Late</div>
            </div>
            <div className="bg-blue-100 p-2 rounded">
              <div className="text-blue-800 font-bold">{studentData.currentMonthAttendance.halfDays}</div>
              <div className="text-xs text-blue-600">Half Day</div>
            </div>
          </div>
        </div>
        
        {/* Yearly Attendance Card */}
        <div className="bg-white border rounded-lg shadow-sm p-4">
          <h2 className="text-lg font-semibold mb-3">Yearly Attendance</h2>
          <div className="flex items-center mb-3">
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div 
                className={`h-4 rounded-full ${getStatusColor(studentData.yearlyAttendance.percentage).bg}`} 
                style={{ width: `${studentData.yearlyAttendance.percentage}%` }}
              ></div>
            </div>
            <span className={`ml-3 font-bold ${getStatusColor(studentData.yearlyAttendance.percentage).text}`}>
              {studentData.yearlyAttendance.percentage}%
            </span>
          </div>
          <div className="flex justify-between text-sm text-gray-600 mb-1">
            <span>Total Working Days: {studentData.yearlyAttendance.totalWorkingDays}</span>
            <span>Days Present: {studentData.yearlyAttendance.presentDays}</span>
          </div>
          <div className="text-xs text-gray-500">
            Academic Year 2024-2025 (April - March)
          </div>
        </div>
      </div>
      
      {/* Monthly Attendance Table */}
      <div className="mb-8">
        <h2 className="text-lg font-semibold mb-3">Monthly Attendance Summary</h2>
        <div className="overflow-x-auto shadow ring-1 ring-black ring-opacity-5 rounded-lg">
          <table className="min-w-full divide-y divide-gray-300">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">Month</th>
                <th scope="col" className="px-3 py-3.5 text-center text-sm font-semibold text-gray-900">Working Days</th>
                <th scope="col" className="px-3 py-3.5 text-center text-sm font-semibold text-gray-900">Days Present</th>
                <th scope="col" className="px-3 py-3.5 text-center text-sm font-semibold text-gray-900">Percentage</th>
                <th scope="col" className="px-3 py-3.5 text-center text-sm font-semibold text-gray-900">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 bg-white">
              {monthlyData.map((month) => (
                <tr key={month.month} className={month.month === selectedMonth ? 'bg-indigo-50' : ''}>
                  <td className="whitespace-nowrap py-2 pl-4 pr-3 text-sm font-medium text-gray-900">{month.month}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-sm text-center">{month.working}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-sm text-center">{month.present}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-sm text-center">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      getStatusColor(month.percentage).bg === 'bg-green-500'
                        ? 'bg-green-100 text-green-800'
                        : getStatusColor(month.percentage).bg === 'bg-yellow-500'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {month.percentage}%
                    </span>
                  </td>
                  <td className="whitespace-nowrap px-3 py-2 text-sm text-center">
                    <button 
                      className={`text-indigo-600 hover:text-indigo-900 ${month.month === selectedMonth ? 'font-bold' : ''}`}
                      onClick={() => handleMonthSelect(month.month)}
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Daily Attendance History */}
      <div>
        <h2 className="text-lg font-semibold mb-3">Daily Attendance for {selectedMonth}</h2>
        <div className="overflow-x-auto shadow ring-1 ring-black ring-opacity-5 rounded-lg">
          <table className="min-w-full divide-y divide-gray-300">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">Date</th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Day</th>
                <th scope="col" className="px-3 py-3.5 text-center text-sm font-semibold text-gray-900">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 bg-white">
              {dailyAttendance.map((record) => (
                <tr key={record.date}>
                  <td className="whitespace-nowrap py-2 pl-4 pr-3 text-sm font-medium text-gray-900">{record.date}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-sm text-gray-900">{record.day}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-sm text-center">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDayStatusColor(record.status)}`}>
                      {record.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
    </div>
  );
};

export default StudentAttendanceComponent;
