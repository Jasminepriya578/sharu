import React, { useState } from 'react';

interface ClassType {
  id: number;
  name: string;
  standard: number;
  section: string;
  studentCount: number;
}

type AttendanceStatus = 'present' | 'absent' | 'late' | 'half-day';

interface Student {
  id: number;
  rollNo: string;
  name: string;
  status: AttendanceStatus | null;
}

const TeacherAttendanceComponent: React.FC = () => {
  // Sample data - would come from an API in a real implementation
  const [classes, setClasses] = useState<ClassType[]>([
    { id: 1, name: 'Class 6A', standard: 6, section: 'A', studentCount: 42 },
    { id: 2, name: 'Class 8B', standard: 8, section: 'B', studentCount: 39 },
    { id: 3, name: 'Class 10C', standard: 10, section: 'C', studentCount: 45 }
  ]);

  const [selectedClass, setSelectedClass] = useState<number | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().substr(0, 10)
  );
  const [students, setStudents] = useState<Student[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [attendanceType, setAttendanceType] = useState<'morning' | 'afternoon'>('morning');

  // Function to format date in Indian style (DD-MM-YYYY with weekday)
  const formatIndianDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      weekday: 'short'
    });
  };

  // Simulate fetching students when a class is selected
  const handleClassSelect = (classId: number): void => {
    setIsLoading(true);
    setSelectedClass(classId);

    // Simulate API call
    setTimeout(() => {
      const sampleStudents: Student[] = [
        { id: 1, rollNo: '01', name: 'Arjun Sharma', status: null },
        { id: 2, rollNo: '02', name: 'Priya Patel', status: null },
        { id: 3, rollNo: '03', name: 'Rahul Verma', status: null },
        { id: 4, rollNo: '04', name: 'Ananya Singh', status: null },
        { id: 5, rollNo: '05', name: 'Vikram Reddy', status: null },
        { id: 6, rollNo: '06', name: 'Sneha Gupta', status: null },
        { id: 7, rollNo: '07', name: 'Aditya Kumar', status: null },
        { id: 8, rollNo: '08', name: 'Meera Joshi', status: null },
        { id: 9, rollNo: '09', name: 'Rohan Malhotra', status: null },
        { id: 10, rollNo: '10', name: 'Neha Kapoor', status: null }
      ];

      setStudents(sampleStudents);
      setIsLoading(false);
    }, 800);
  };

  // Handle bulk actions to mark all students
  const handleMarkAll = (status: AttendanceStatus): void => {
    setStudents(students.map(student => ({ ...student, status })));
  };

  // Handle attendance status change for a student
  const handleAttendanceChange = (studentId: number, status: AttendanceStatus): void => {
    setStudents(
      students.map(student =>
        student.id === studentId ? { ...student, status } : student
      )
    );
  };

  // Handle save attendance
  const handleSaveAttendance = (): void => {
    setIsSaving(true);

    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      setSaveSuccess(true);

      setTimeout(() => {
        setSaveSuccess(false);
      }, 3000);
    }, 1000);
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Daily Attendance Register</h1>
        <p className="text-gray-600">Mark attendance for your assigned classes</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Select Class</label>
          <select
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            onChange={(e: React.ChangeEvent<HTMLSelectElement>) =>
              handleClassSelect(parseInt(e.target.value))
            }
            value={selectedClass || ''}
          >
            <option value="">-- Select Class --</option>
            {classes.map(cls => (
              <option key={cls.id} value={cls.id}>
                {cls.name} ({cls.studentCount} students)
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Date</label>
          <input
            type="date"
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            value={selectedDate}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSelectedDate(e.target.value)}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Attendance Type</label>
          <div className="flex items-center space-x-4">
            <label className="inline-flex items-center">
              <input
                type="radio"
                className="form-radio h-4 w-4 text-indigo-600"
                name="attendanceType"
                value="morning"
                checked={attendanceType === 'morning'}
                onChange={() => setAttendanceType('morning')}
              />
              <span className="ml-2 text-sm text-gray-700">Morning</span>
            </label>
            <label className="inline-flex items-center">
              <input
                type="radio"
                className="form-radio h-4 w-4 text-indigo-600"
                name="attendanceType"
                value="afternoon"
                checked={attendanceType === 'afternoon'}
                onChange={() => setAttendanceType('afternoon')}
              />
              <span className="ml-2 text-sm text-gray-700">Afternoon</span>
            </label>
          </div>
        </div>
      </div>

      {selectedClass && !isLoading && (
        <div className="mb-4 bg-indigo-50 p-4 rounded-lg flex justify-between items-center">
          <div>
            <h2 className="font-semibold text-indigo-800">
              {classes.find(c => c.id === selectedClass)?.name} - {formatIndianDate(selectedDate)}
            </h2>
            <p className="text-sm text-indigo-600">
              {attendanceType === 'morning' ? 'Morning Session' : 'Afternoon Session'}
            </p>
          </div>
          <div>
            <span className="text-sm bg-white px-2 py-1 rounded border border-indigo-200">
              Total: {students.length} students
            </span>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="text-center py-10">
          <p className="text-gray-500">Loading class roster...</p>
        </div>
      ) : selectedClass && students.length > 0 ? (
        <>
          <div className="bg-gray-50 p-4 rounded-md mb-6">
            <div className="flex flex-wrap gap-2">
              <button
                className="px-3 py-1 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 text-sm"
                onClick={() => handleMarkAll('present')}
              >
                Mark All Present
              </button>
              <button
                className="px-3 py-1 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 text-sm"
                onClick={() => handleMarkAll('absent')}
              >
                Mark All Absent
              </button>
              <div className="ml-auto">
                <button
                  className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  onClick={handleSaveAttendance}
                  disabled={isSaving}
                >
                  {isSaving ? 'Saving...' : 'Save Attendance'}
                </button>
              </div>
            </div>
          </div>

          {saveSuccess && (
            <div className="mb-4 p-3 bg-green-100 text-green-800 rounded-md border border-green-200">
              Attendance saved successfully for {classes.find(c => c.id === selectedClass)?.name}!
            </div>
          )}

          <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 rounded-lg">
            <table className="min-w-full divide-y divide-gray-300">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 w-16"
                  >
                    Roll No.
                  </th>
                  <th
                    scope="col"
                    className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900"
                  >
                    Student Name
                  </th>
                  <th
                    scope="col"
                    className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900"
                  >
                    Status
                  </th>
                  <th
                    scope="col"
                    className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900 w-32"
                  >
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 bg-white">
                {students.map((student, index) => (
                  <tr key={student.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="whitespace-nowrap py-3 pl-4 pr-3 text-sm font-medium text-gray-900">
                      {student.rollNo}
                    </td>
                    <td className="whitespace-nowrap px-3 py-3 text-sm text-gray-900">
                      {student.name}
                    </td>
                    <td className="whitespace-nowrap px-3 py-3 text-sm">
                      {student.status === 'present' && (
                        <span className="text-green-600 font-medium">Present</span>
                      )}
                      {student.status === 'absent' && (
                        <span className="text-red-600 font-medium">Absent</span>
                      )}
                      {student.status === 'late' && (
                        <span className="text-yellow-600 font-medium">Late</span>
                      )}
                      {student.status === 'half-day' && (
                        <span className="text-blue-600 font-medium">Half Day</span>
                      )}
                      {!student.status && <span className="text-gray-400">Not marked</span>}
                    </td>
                    <td className="whitespace-nowrap px-3 py-3 text-sm">
                      <div className="flex space-x-1">
                        <button
                          onClick={() => handleAttendanceChange(student.id, 'present')}
                          className={`w-6 h-6 rounded-full flex items-center justify-center ${
                            student.status === 'present'
                              ? 'bg-green-500 text-white'
                              : 'bg-gray-200 text-gray-600 hover:bg-green-100'
                          }`}
                          title="Present"
                        >
                          P
                        </button>
                        <button
                          onClick={() => handleAttendanceChange(student.id, 'absent')}
                          className={`w-6 h-6 rounded-full flex items-center justify-center ${
                            student.status === 'absent'
                              ? 'bg-red-500 text-white'
                              : 'bg-gray-200 text-gray-600 hover:bg-red-100'
                          }`}
                          title="Absent"
                        >
                          A
                        </button>
                        <button
                          onClick={() => handleAttendanceChange(student.id, 'late')}
                          className={`w-6 h-6 rounded-full flex items-center justify-center ${
                            student.status === 'late'
                              ? 'bg-yellow-500 text-white'
                              : 'bg-gray-200 text-gray-600 hover:bg-yellow-100'
                          }`}
                          title="Late"
                        >
                          L
                        </button>
                        <button
                          onClick={() => handleAttendanceChange(student.id, 'half-day')}
                          className={`w-6 h-6 rounded-full flex items-center justify-center ${
                            student.status === 'half-day'
                              ? 'bg-blue-500 text-white'
                              : 'bg-gray-200 text-gray-600 hover:bg-blue-100'
                          }`}
                          title="Half Day"
                        >
                          H
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      ) : selectedClass ? (
        <div className="text-center py-10 bg-gray-50 rounded-md">
          <p className="text-gray-500">No students found for this class.</p>
        </div>
      ) : (
        <div className="text-center py-10 bg-gray-50 rounded-md">
          <p className="text-gray-500">Please select a class to view and mark attendance.</p>
        </div>
      )}
    </div>
  );
};

export default TeacherAttendanceComponent;
